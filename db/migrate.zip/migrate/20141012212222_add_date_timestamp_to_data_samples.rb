class AddDateTimestampToDataSamples < ActiveRecord::Migration
  # def change
  # 	change_table :data_samples do |t|
  # 		t.string :date_timestamp
  # 	end
  # 	DataSample.all.each do |ds|
  # 		ds.date_timestamp = Time.new(ds.sample_time).to_i
  # 		ds.save
  # 	end
  # end
end
